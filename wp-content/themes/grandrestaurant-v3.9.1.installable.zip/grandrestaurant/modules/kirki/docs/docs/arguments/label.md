---
layout: default
title: label
published: true
mainMaxWidth: 50rem;
---

The `label` argument is used to set a control's title and is available on all control-types.
