<?php

add_action( 'wp_enqueue_scripts', 'enqueue_parent_styles' );

function enqueue_parent_styles() {
   wp_enqueue_style( 'parent-style', get_template_directory_uri().'/style.css' );
}

// WooCommerce functions
/**
 * Set a minimum order amount for checkout
 */
// add_action( 'woocommerce_checkout_process', 'wc_minimum_order_amount' );
// add_action( 'woocommerce_before_cart' , 'wc_minimum_order_amount' );
 
// function wc_minimum_order_amount() {
//     // Set this variable to specify a minimum order value
//     $minimum = 60;

//     if ( WC()->cart->total < $minimum ) {

//         if( is_cart() ) {

//             wc_print_notice( 
//                 sprintf( 'Your current order total is %s — your cart must have a minimum of %s to place your order. <a style="text-decoration: underline" href="/meals-to-go">Continue shopping</a> ' , 
//                     wc_price( WC()->cart->total ), 
//                     wc_price( $minimum )
//                 ), 'error' 
//             );

//         } else {

//             wc_add_notice( 
//                 sprintf( 'Your current order total is %s — your cart must have a minimum of %s to place your order.  <a style="text-decoration: underline" href="/meals-to-go">Continue shopping</a> ' , 
//                     wc_price( WC()->cart->total ), 
//                     wc_price( $minimum )
//                 ), 'error' 
//             );

//         }
//     }
// }