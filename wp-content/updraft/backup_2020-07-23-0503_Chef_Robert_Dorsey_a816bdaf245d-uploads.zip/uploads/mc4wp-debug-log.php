<?php exit; ?>
[2018-05-16 21:44:23] WARNING: Form 4070 > rdor****@gm***.com is already subscribed to the selected list(s)
[2020-03-30 09:42:03] ERROR: Form 4070 > Mailchimp API error: 401 Unauthorized. API Key Invalid. Your API key may be invalid, or you've attempted to access the wrong datacenter.
Request: GET https://us5.api.mailchimp.com/3.0/lists/a18ef84f2c/members/0290ef2a12b4b4bb724a1680a8808e16
Response: 401 Unauthorized - {"type":"http://developer.mailchimp.com/documentation/mailchimp/guides/error-glossary/","title":"API Key Invalid","status":401,"detail":"Your API key may be invalid, or you've attempted to access the wrong datacenter.","instance":"fb5bf31c-85c0-4fe5-98d8-e471921f81e5"}
[2020-03-30 09:57:55] ERROR: Form 4070 > Mailchimp API error: 401 Unauthorized. API Key Invalid. Your API key may be invalid, or you've attempted to access the wrong datacenter.
Request: GET https://us5.api.mailchimp.com/3.0/lists/a18ef84f2c/members/0290ef2a12b4b4bb724a1680a8808e16
Response: 401 Unauthorized - {"type":"http://developer.mailchimp.com/documentation/mailchimp/guides/error-glossary/","title":"API Key Invalid","status":401,"detail":"Your API key may be invalid, or you've attempted to access the wrong datacenter.","instance":"a5212d50-bc6b-4813-8606-3230d62b2529"}
